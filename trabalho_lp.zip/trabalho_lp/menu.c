#include <stdio.h>
#include <stdlib.h>
#include "cliente.h"
#include "encomenda.h"
#include "maquina.h"
#include "input.h"
#include "menu.h"



void MenuClientes(Listaclientes *lista,Listaencomendas *listaEncomendas) {
    int menuopcl;
    do {
        printf("\n--------------------------------\n");
        printf("Menu dos Clientes:\n");
        printf("1. Adicionar cliente\n");
        printf("2. Listar clientes\n");
        printf("3. Remover cliente\n");
        printf("4. Atualizar cliente\n");
        printf("5. Procurar cliente\n");
        printf("Relatórios:\n");
        printf("6. Quantidade de clientes\n");
        printf("7. Encomendas por cliente\n");
        printf("8. Cliente mais ativo\n");
        printf("9. Voltar \n");
        printf("10. Sair\n");
        printf("--------------------------------\n");

        menuopcl = valorintpequeno(MIN_VL_OP, 10, MSG_OP);

        switch (menuopcl) {
            case 1:
                addcliente(lista);
                break;
            case 2:
                listarclientes(lista);
                break;
            case 3:
                removerclientes(lista);
                break;
            case 4:
                attclientes(lista);
                break;
            case 5:
                procurarclientes(lista);
                break;
            case 6:
                relatorioqntClientes(lista);
                break;
            case 7:
                detalhesEncomendasPorCliente(lista,listaEncomendas);
                break;
            case 8:
                 clienteMaisAtivo(lista, listaEncomendas);
                break;
            case 9:
                printf("Menu principal:\n");
                break;
            case 10:
                liberarLista(lista);
                printf("Obrigado pela preferencia !!!\n");
                exit(0);
                break;
            default:
                printf("Opção inválida. Tente novamente.\n");
                break;
        }
    } while (menuopcl != 9);
}

void MenuEncomendas(Listaencomendas *lista,Listaclientes *listaClientes,categoria_produtos *produtos) {
    int opcao;
    int total_encomendas;
    do {
        printf("\n--------------------------------\n");
        printf("Menu de Gestão de Encomendas:\n");
        printf("1. Adicionar Encomenda\n");
        printf("2. Procurar Encomenda\n");
        printf("3. Atualizar Encomenda\n");
        printf("4. Remover Encomenda\n");
        printf("Relatórios:\n");
        printf("5. Listar por Estado\n");
        printf("6. Listar por Prioridade\n");
        printf("7. Listar todas as Encomendas\n");
        printf("10. Algoritmo\n");
        printf("11. teste produção\n");
        printf("8. Voltar \n");
        printf("9. Sair\n");
        
        printf("--------------------------------\n");

       opcao = valorintpequeno(1,11,MSG_OP);

        switch (opcao) {
            case 1:
                
                if (listaClientes->contcliente ==0 || produtos->contador == 0){
                    printf ("Não existem clientes ou produtos!!!!\n");
                }else{
                    listarTodosClientes(listaClientes);
                    mostrarprodutos(produtos);
                    criar_Encomendas(lista);
                }
                break;
            case 2:
                procurar_Encomendas(*lista);
                break;
            case 3:
                att_Encomendas(lista);
                break;
            case 4:
                Rmv_Encomendas(lista);
                break;
            case 5: {
                int estado = valorintpequeno(1, 3, "Informe o estado (1->Aberta, 2->Produção, 3->Finalizada): ");
                listar_Estado_encomenda(lista, estado);
                break;
            }
            case 6: {
                int prioridade = valorintpequeno(1, 3, "Informe a prioridade (1->Baixa, 2->Média, 3->Alta): ");
                listar_encomendas_prioridade(*lista, prioridade);
                break;
            }
            case 7:
                Ver_Todas_encomendas(lista);
                break;
            case 8:
                 printf("Menu Principal:\n");
                return;
                break;
            
            case 9:
                liberar_encomendas(lista);
                printf("Obrigado pela preferencia!!!\n");
                exit(0);
                break;
           case 10:
                Listar_encomendas_auto(lista);
                break;
            case 11:
                //calcular_Tempo_Producao(lista);
                //calcular_tempo_encomenda_fi(lista,produtos);
                //gerarRelatorioProducao(lista,total_encomendas,produtos);
                calcularTempoEncomenda(lista,produtos);
                break;
            default:
                printf("Opção inválida.\n");
                break;
        }
    } while (opcao != 12);
}

//alterei aqui
void MenuProdutos(categoria_produtos *categoria,MaquinasGeral *listaMaquinas) {
    int opcao;
    
    do {
        // Exibe o menu de opções
        printf("\n--------------------------------\n");
        printf("Menu de Gestão de Produtos:\n");
        printf("1. Adicionar Produto\n");
        printf("2. Mostrar Produtos\n");
        printf("3. Atualizar Produto\n");
        printf("4. Eliminar Produto\n");
        printf("Relatórios:\n");
        printf("5. Contar Total de Produtos\n");
        printf("6. Contar Produtos por Categoria\n");
        printf("7. Maior e Menor Tamanho de Produto\n");
        printf("8. Voltar\n");
        printf("9. Sair\n");
        printf("\n--------------------------------\n");
         opcao = valorintpequeno (1,9,MSG_OP);
        printf("\n--------------------------------\n");
        switch (opcao) {
            case 1:
                // Inserir produto
                if(listaMaquinas->contMaq == 0){
                    printf("Não pode criar um produto sem criar uma máquina!!!!\n");
                    }else{
                inserir_Produto(categoria);
                    }
                break;
            case 2:
                // Listar produtos
                ler_Produto(*categoria);
                break;
            case 3:
                // Atualizar produto
                atualizar_Produto(categoria);
                break;
            case 4:
                // Eliminar produto
                eliminar_Produto(categoria);
                break;
            case 5:
                // Contar total de produtos
                printf("Total de produtos: %d\n", TotalProdutos(*categoria));
                break;
            case 6:
                // Contar produtos por categoria
                {
                    int categorias[MAX_CATEGORIA] = {0};  // Um array para contar os produtos por categoria
                    Produtos_Categoria(*categoria, categorias, MAX_CATEGORIA);
                    for (int i = 0; i < MAX_CATEGORIA; i++) {
                        printf("Categoria %d: %d produtos\n", i + 1, categorias[i]);
                    }
                }
                break;
            case 7:
                // Maior e menor tamanho de produto
                {
                    Produto maior, menor;
                    if (Maior_Menor_Tamanho(*categoria, &maior, &menor) == 0) {
                        printf("Maior produto: ID: %d, Nome: %s, Tamanho: %d\n", maior.id_produto, maior.nome_produto, maior.tamanho_roupa);
                        printf("Menor produto: ID: %d, Nome: %s, Tamanho: %d\n", menor.id_produto, menor.nome_produto, menor.tamanho_roupa);
                    }
                }
                break;
            case 8:
                // Sair
                printf("Menu Principal:\n");
                return;
                break;
            case 9:
                printf("Obrigado pela preferencia!!!\n");
                exit(0);
            break;    
            default:
                printf("Opção inválida! Tente novamente.\n");
                break;
        }
    } while (opcao != 9);  // O loop continua até o usuário escolher sair
}

//menu para as máquinas

void MenuMaquinas(MaquinasGeral *listaMaquinas,categoria_produtos *categoria) {
    int opcao;
    
    do {
        // Exibe o menu de opções
        printf("\n--------------------------------\n");
        printf("Menu de Gestão de Máquinas:\n");
        printf("1. Adicionar Máquina\n");
        printf("2. Mostrar Máquina\n");
        printf("3. Atualizar Máquina\n");
        printf("4. Eliminar Máquina\n");
        printf("Relatórios:\n");
        printf("5. Máquina mais utlizada\n");
        printf("6. Tempo médio de produção\n");
        printf("7. Tempo máximo e minimo de produção\n");
        printf("8. Voltar\n");
        printf("9. Sair\n");
        printf("\n--------------------------------\n");
         opcao = valorintpequeno (1,9,MSG_OP);
        printf("\n--------------------------------\n");
        switch (opcao) {
            case 1:
                // Inserir maquina
                inserir_Maquina(listaMaquinas);
                
                break;
            case 2:
                // Listar maquina
                listar_Maquinas(listaMaquinas);
                break;
            case 3:
                // Atualizar maquina
                atualizar_Maquinana_Lista(listaMaquinas);
                break;
            case 4:
                // Eliminar maquina
                remover_Maquinana_Lista(listaMaquinas);
                break;
            case 5:
                maquinas_Mais_Utilizadas(*listaMaquinas); 
                break;
            case 6:
                // Contar produtos por categoria
                tempo_Medio_Producao(listaMaquinas,categoria);
                break;
            case 7:
            tempo_Maximo_Minimo_Producao(listaMaquinas,categoria);
                
                break;
            case 8:
                // Sair
                printf("Menu Principal:\n");
                return;
                break;
            case 9:
                printf("Obrigado pela preferencia!!!\n");
                exit(0);
            break;    
            default:
                printf("Opção inválida! Tente novamente.\n");
                break;
        }
    } while (opcao != 9);  // O loop continua até o usuário escolher sair
}


void Menuprincipal() {
    Listaclientes listaClientes;
    Listaencomendas listaEncomendas;
    categoria_produtos categoria;
    MaquinasGeral listaMaquinas;

    inicializarLista(&listaClientes, CAPACIDADE_INICIAL);
    inicializar_encomendas(&listaEncomendas, CAPACIDADE_INICIAL);
    iniciar_categoria(&categoria, CAPACIDADE_INICIAL);
    inicializar_Maquinas(&listaMaquinas,CAPACIDADE_INICIAL);

    int opmenupr;
    do {
        printf("--------------------------------\n");
        printf("=== Gestão da empresa XPTO ===\n");
        printf("1 -> Clientes\n");
        printf("2 -> Produtos\n");
        printf("3 -> Encomendas\n");
        printf("4 -> Máquinas\n");
        printf("5 -> Sair\n");
        printf("--------------------------------\n");

        opmenupr = valorintpequeno(MIN_VL_OP, MAX_VL_OP, MSG_OP);

        switch (opmenupr) {
            case 1:
                MenuClientes(&listaClientes,&listaEncomendas);
                break;
            case 2:
               MenuProdutos(&categoria,&listaMaquinas);
                break;
            case 3:
                MenuEncomendas(&listaEncomendas,&listaClientes,&categoria);
                break;
            case 4:
                MenuMaquinas(&listaMaquinas,&categoria);
                break;
            case 5:
                printf("Obrigado pela preferencia!!!\n");
                liberarLista(&listaClientes);
                liberar_encomendas(&listaEncomendas);
                exit(0);
                break;
            default:
                printf("Opção inválida. \n");
                break;
        }
    } while (opmenupr != 5);

    liberarLista(&listaClientes);
    liberar_encomendas(&listaEncomendas);
    apagar_categoria(&categoria);
    libertar_Memoria_Maquinas(&listaMaquinas);
}


