/* 
 * File:   cliente.h
 * Author: David Fernandes
 *
 * Created on 28 de novembro de 2024, 11:31
 * @brief Neste ficheiro vou declarar as funções de dos clientes para usar noutras páginas.
 * Este ficheiro comtem as funções para depois poder usar noutras paginas
 */

#ifndef CLIENTE_H
#define CLIENTE_H
//includes 
#include <time.h>
#include "encomenda.h"
//Defines para os clientes
#define CLIENTE_JA_EXISTE "O cliente já existe!"
#define ERRO_ARRAY_VAZIA "A lista dos clientes está vazia!"
#define ERRO_ARRAY_CHEIA "A lista dos clientes está cheia!"
#define ERRO_CLIENTE_NAO_EXISTE "O cliente não existe!"
//Defines para o nome do cliente
#define MAX_NOME_CLIENTE 50
#define MSG_OBTER_NOME_CLIENTE "Qual o nome do cliente:\n"
//Define para o id do cliente
#define MSG_OBTER_ID_CLI "Id do cliente [1-100].\n"
#define NUM_MIN_CLIENTES 1
#define NUM_MAX_CLIENTES 100
//Defines para o nif do cliente
#define NUM_MIN_NIF_CLIENTES 100000000
#define NUM_MAX_NIF_CLIENTES 999999999
#define MSG_NIF_CLIENTES "Qual o nif do cliente:\n"
//Define para o numero de telefone do cliente
#define MSG_OBTER_TELEFONE "Qual o telefone do cliente:\n"
#define NUM_MIN_TELEFONE 900000000
#define NUM_MAX_TELEFONE 999999999
//Define para o email do cliente
#define MSG_OBTER_EMAIL "Qual o email do cliente [Tipo de email valido: *****@gmail.com]:\n"
#define MAX_CAR_EMAIL 40

#ifdef __cplusplus
extern "C" {
#endif
// estreutura para os contactos dos clientes
typedef struct {
    int telefone;
    char email[MAX_CAR_EMAIL];
} Contacto;
// estrutura para o registo do cliente
typedef struct {
    int dia, mes, ano;
} Data;
// estrutura do cliente ou seja todas as informações de 1 cliente
typedef struct {
    char nome[MAX_NOME_CLIENTE];
    int idcliente;
    int nif;
    Contacto contactos;
    Data registocliente;
} Cliente;
//estrutura para a lista de clientes
typedef struct {
    int contcliente;
    int capacidade;
    Cliente *arraysclientes; 
} Listaclientes;

// Funções para a memoria dinamica
void inicializarLista(Listaclientes *lista, int capacidadeInicial);
void liberarLista(Listaclientes *lista);
void redimensionarLista(Listaclientes *lista);

// Funções para CRUD
//Adiciona cientes
int addcliente(Listaclientes *lista);
//Atualiza clientes
void attclientes(Listaclientes *lista);
//Remove Clientes
void removerclientes(Listaclientes *lista);
//Lista clientes
void listarclientes(Listaclientes *lista);
//Procura clientes
void procurarclientes(Listaclientes *lista);

// Funções auxiliares que complemnetam as do crud
void attcliente(Cliente *cliente);
void removercliente(Cliente *cliente);
void listarcliente(Cliente *cliente);
int procurarcliente(Listaclientes *lista, int id); 

//funções para os relatórios dos clientes
//Relatório de quantidade de clientes no sistema
 void relatorioqntClientes(Listaclientes *lista);
 //Relatório para o cliente mais ativo
 void clienteMaisAtivo(Listaclientes *listaClientes, Listaencomendas *listaEncomendas);//errro nao esta a dar 
 //Relatório para ver detalhes das encomendas de cada cliente
 void detalhesEncomendasPorCliente(Listaclientes *clientes ,Listaencomendas *encomendas);//erro nao esta a dar
 
 //função quelista todos os clientes que estão no sistema para as encomendas
 void listarTodosClientes(Listaclientes *clientes);

#ifdef __cplusplus
}
#endif

#endif /* CLIENTE_H */