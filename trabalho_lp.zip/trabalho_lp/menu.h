/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cFiles/file.h to edit this template
 */

/* 
 * File:   menu.h
 * Author: David Fernandes
 *
 * Created on 13 de dezembro de 2024, 16:04
 */

#ifndef MENU_H
#define MENU_H
#define CAPACIDADE_INICIAL 5
#define MIN_VL_OP 1
#define MAX_VL_OP 5
#define MSG_OP "\nOpção->"

#ifdef __cplusplus
extern "C" {
#endif


void MenuClientes(Listaclientes *lista,Listaencomendas *listaEncomendas);    
void MenuEncomendas(Listaencomendas *lista,Listaclientes *listaClientes,categoria_produtos *produtos); 
void MenuProdutos(categoria_produtos *categoria,MaquinasGeral *listaMaquinas); 
void MenuMaquinas(MaquinasGeral *listaMaquinas,categoria_produtos *categoria);
void Menuprincipal();


#ifdef __cplusplus
}
#endif

#endif /* MENU_H */

