/* 
 * File:   cliente.c
 * Author: David Fernandes
 *
 * Created on 28 de novembro de 2024, 11:31
 * @brief Neste ficheiro vou declarar as funções dos clientes.
 * Este ficheiro comtem as funções desenvolvidas dos clientes como asn do crud e as dos relatórios
 */


//Incluir bibliotecas 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "cliente.h"
#include "encomenda.h"
#include "input.h"

//Função para criar uma lista com memoria dinamica de 10 caixas para usar
void inicializarLista(Listaclientes *lista, int capacidadeInicial) {
    lista->contcliente = 0;
    lista->capacidade = capacidadeInicial;
    //cria memoria dinamica do tipo Listaclientes com tamanho 10
    lista->arraysclientes = malloc(capacidadeInicial * sizeof(Cliente));
    if (!lista->arraysclientes) {
        perror("Erro ao alocar memória");
        exit(EXIT_FAILURE);
    }
}

//Acabar com a lista de memoria dinamica quando encerro o programa
void liberarLista(Listaclientes *lista) {
    free(lista->arraysclientes);
    lista->arraysclientes = NULL;
    lista->contcliente = 0;
    lista->capacidade = 0;
}

//Aumentar o tamanho da lista se necesssario
void redimensionarLista(Listaclientes *lista) {
    // dobra a capacidade pata ter clientes
    lista->capacidade *= 2;
    Cliente *novaLista = realloc(lista->arraysclientes, lista->capacidade * sizeof(Cliente));// ao ineves de criar uma lista nova ele dobra o espaço
    if (!novaLista) {
        perror("Erro ao redimensionar memória");
        exit(EXIT_FAILURE);
    }
    lista->arraysclientes = novaLista;
}

// Procura um cliente pelo ID
int procurarcliente(Listaclientes *lista, int id) {
    int i;
    //percorre o array do contador dos clientes e compara se o id da posicção i é igual ao q procuramos
    //Se sim retorna o id
    for (i = 0; i < lista->contcliente; i++) {
        if (lista->arraysclientes[i].idcliente == id) {
            return i;
        }
    }
    return -1;
}




// Adiciona um cliente 
int addcliente(Listaclientes *lista) {
    // se o tivermos no sistema os mesmos clientes que a capacidade da lista ele chama uma função para dar mais espaço
    if (lista->contcliente == lista->capacidade) {
        redimensionarLista(lista);
    }   
    //verifica se o id do cliente não é repetido
    
    //asdiciona as informações respetivas ao cliente
    Cliente *novo_cliente = &lista->arraysclientes[lista->contcliente];
    novo_cliente->idcliente = lista->contcliente+1;
    lerfrase(novo_cliente->nome, MAX_NOME_CLIENTE, MSG_OBTER_NOME_CLIENTE);
    novo_cliente->nif = valorintpequeno(NUM_MIN_NIF_CLIENTES, NUM_MAX_NIF_CLIENTES, MSG_NIF_CLIENTES);
    novo_cliente->contactos.telefone = valorintpequeno(NUM_MIN_TELEFONE, NUM_MAX_TELEFONE, MSG_OBTER_TELEFONE);
    emailcheck2(novo_cliente->contactos.email, MAX_CAR_EMAIL, MSG_OBTER_EMAIL);
    novo_cliente->registocliente.dia =registoDia() ;
    novo_cliente->registocliente.mes =registoMes() ;
    novo_cliente->registocliente.ano= registoAno();
    //ecrementra 1 valor ao contador a cada vez que um cliente é adicionado
    lista->contcliente++;
    return 0;
}

// Lista todos os clientes
void listarclientes(Listaclientes *lista) {
    int i;
    if (lista->contcliente == 0) {
        puts(ERRO_ARRAY_VAZIA);
        return;
    }
    
    for (i = 0; i < lista->contcliente; i++) {
        //lista o cliente da pocição i
        listarcliente(&lista->arraysclientes[i]);
    }
}

// Lista um cliente individual
void listarcliente( Cliente *cliente) {
    printf("----------------------------\nInformações sobre o cliente %d \n---------------------------\nNome: %s\nId: %d\nNif: %d\nTelefone: %d\nEmail: %s\nData de registo: %d-%d-%d\n--------------------------\n",
           cliente->idcliente,cliente->nome, cliente->idcliente, cliente->nif, cliente->contactos.telefone,
           cliente->contactos.email, cliente->registocliente.dia, cliente->registocliente.mes,
           cliente->registocliente.ano);
}

// Remove um cliente
void removerclientes(Listaclientes *lista) {
    int i;
    int id = valorintpequeno(NUM_MIN_CLIENTES, NUM_MAX_CLIENTES, MSG_OBTER_ID_CLI);
    //decalaro indice como id do cliente que queremos remover
    int indice = procurarcliente(lista, id);

    if (indice == -1) {
        puts(ERRO_CLIENTE_NAO_EXISTE);
        return;
    }
    //remove o cliente e tira 1 ao contador
    for (i = indice; i < lista->contcliente - 1; i++) {
        lista->arraysclientes[i] = lista->arraysclientes[i + 1];
    }
    lista->arraysclientes->idcliente--;
    lista->contcliente--;
    puts("Cliente removido com sucesso!");
}
//verificações para atualizar cliente
void attclientes(Listaclientes *lista) {
    //verifica se o contador nao esta a 0
    if (lista->contcliente == 0) { 
        puts(ERRO_ARRAY_VAZIA);
        return; 
        }
    //pede o valor do id que queremos att
    int id = valorintpequeno(NUM_MIN_CLIENTES, NUM_MAX_CLIENTES, MSG_OBTER_ID_CLI);
    //chamar a função de procurar clientee guardar no indice
    int indice = procurarcliente(lista, id); 
    //verificar que o indice existe 
    if (indice == -1) { 
        puts(ERRO_CLIENTE_NAO_EXISTE); 
        return; 
    } 
    // cria um apontador cliente do tipo cliente que iguala na lista de clinetes o cliente que queremos atualizar
    Cliente *cliente = &lista->arraysclientes[indice];
    printf("Novas informações do cliente %d\n", id); 
    attcliente(cliente);
  
}
 // função para atualizar os dados do cliente
void attcliente(Cliente *cliente) {
 if (cliente == NULL) { 
puts("Cliente inválido!");
 return; 
} // Atualizar nome do cliente 
lerfrase(cliente->nome, MAX_NOME_CLIENTE, MSG_OBTER_NOME_CLIENTE);
 // Atualizar  telefone do cliente 
cliente->contactos.telefone = valorintpequeno(NUM_MIN_TELEFONE, NUM_MAX_TELEFONE, MSG_OBTER_TELEFONE); 
// Atualizar email do cliente 
emailcheck2(cliente->contactos.email, MAX_CAR_EMAIL, MSG_OBTER_EMAIL); 
puts("Informações do cliente atualizadas com sucesso!");
 }


//função procurar cliente
 void procurarclientes(Listaclientes *lista) { 
     //verifica se há clientes
     if (lista->contcliente == 0) { 
         puts(ERRO_ARRAY_VAZIA); return; 
     } 
     //pede ao utlizador o id do cliente e chama a função procurar cliente
     int id = valorintpequeno(NUM_MIN_CLIENTES, NUM_MAX_CLIENTES, MSG_OBTER_ID_CLI); 
     int indice = procurarcliente(lista, id); 
     if (indice == -1) { 
         puts(ERRO_CLIENTE_NAO_EXISTE); 
         return;
     } 
     //lista o cliente que esta no indice
     listarcliente(&lista->arraysclientes[indice]);
 }
 
 //função para listar os clientes todos que estão no sistema 
 //usada para ao adicionar encomenda poder ver qual os clientes estão no sistema
 void listarTodosClientes(Listaclientes *clientes) {
     int i;
     //verifica se há clientes no sisitema
    if (clientes->contcliente == 0) {
        printf("A lista de clientes está vazia.\n");
        return;
    }
    printf("------------------------------------\n");
    printf("Clientes no sistema:\n");
    printf("------------------------------------\n");
    //Mostra as infomrções de todos os clientes que estão no sistema
    for (i = 0; i < clientes->contcliente; i++) {
        printf("Cliente %d\n", clientes->arraysclientes[i].idcliente);
        printf("Nome: %s\n", clientes->arraysclientes[i].nome);
        printf("------------------------------------\n");
    }
}
 
 // Relatórios dos clientes
 // relatoro para mostrar os clientes que estão no sistema
 void relatorioqntClientes(Listaclientes *lista){
     printf("Numero  de clientes no sistema: %d Clientes\n", lista->contcliente);
 }

//Relatorio de emcomendas por cliente
void detalhesEncomendasPorCliente(Listaclientes *clientes,Listaencomendas *encomendas) {
    int i,j;
    //verificação se ha clintes ou encomendas
    if (clientes == NULL || clientes->contcliente == 0) {
        printf("Lista dos Clientes vazia!!!.\n");
        return;
    }
    if (encomendas->contador == 0) {
        printf("Lista de encomendas vazia.\n");
        return;
    }
    
    printf("------------------------------------\n");
    printf("Detalhes das encomendas por cliente:\n");
    printf("------------------------------------\n");
    //percorre o array dos clientes
    for (i = 0; i < clientes->contcliente; i++) {
        // cria um apontador do tipo cliente para a posição do cliente no array
        Cliente *clienteAtual = &clientes->arraysclientes[i];
        int totalEncomendas = 0;
        int totalProdutos = 0;

        // Verificar todas as encomendas para este cliente
        for (j = 0; j < encomendas->contador; j++) {
            //verifica se o id que pos na encomenda é igual ao do cliente
            if (encomendas->encomendas[j].id_cliente == clienteAtual->idcliente) {
                //Encrementa 1 ao numero de encomendas feitas pelo cliente
                totalEncomendas++;
                //adiciona o total de produtos nas varias encomendas que o cliente fez
                totalProdutos += encomendas->encomendas[j].numero_produto;
            }
        }

        // Mostrar os detalhes do cliente se ele tiver encomendas
        if (totalEncomendas > 0) {
            printf("Cliente: %s \nID: %d\n", clienteAtual->nome, clienteAtual->idcliente);
            printf("  Total de encomendas: %d\n", totalEncomendas);
            printf("  Total de produtos: %d\n", totalProdutos);
            printf("------------------------------------\n");
        }
    }
}


//Relatorio para o cliente mais ativo 
void clienteMaisAtivo(Listaclientes *listaClientes, Listaencomendas *listaEncomendas) {
    int i;
    int j;
    int maxEncomendas = 0;
    int clienteMaisAtivoID = -1;
    //verifica se há encomendas ou clientes no sistema
    if (listaClientes->contcliente == 0) {
        printf("Não há clientes cadastrados.\n");
        return;
    }
    if (listaEncomendas->contador == 0) {
        printf("Não há encomendas registradas.\n");
        return;
    }

    //Percorre o array dos clientes e guarda a posição do cliente
    for (i = 0; i < listaClientes->contcliente; i++) {
        int encomendasCliente = 0;
        int clienteID = listaClientes->arraysclientes[i].idcliente;

        // Conta as encomendas do cliente feitas 
        for (j = 0; j < listaEncomendas->contador; j++) {
            //verifica se a encomenda foi feita pelo id de cima 
            if (listaEncomendas->encomendas[j].id_cliente == clienteID) {
                //adiciona 1 as encomendas feitas pelo cliente
                encomendasCliente++;
            }
        }

        // Verifica se o cliente atual é o mais ativo
        if (encomendasCliente > maxEncomendas) {
            maxEncomendas = encomendasCliente;
            clienteMaisAtivoID = clienteID;
        }
    }
   // Lista o cliente mais ativo
    if (clienteMaisAtivoID != -1) {
        printf("\nCliente mais ativo:\n");
        printf("ID do cliente: %d\n", clienteMaisAtivoID);
        printf("Total de encomendas: %d\n", maxEncomendas);
    } else {
        printf("Não existem encomendas associadas a clientes.\n");
    }
}



 
