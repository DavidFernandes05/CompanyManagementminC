/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cFiles/main.c to edit this template
 */

/* 
 * File:   entrada.c
 * Author: David Fernandes
 *
 * Neste ficheiro vou desenvolver as funções de validação de entrada de dados.
 */

#include <stdio.h>
#include <stdlib.h>
#include "input.h"
#include "cliente.h"
#include <string.h>
#include <stdbool.h>

//função para limpar o buffer
void limparbuffer () {
    char limpar;
    //faz um ciclo while ate que o char seha diferente que \n ou eof
    while ((limpar=getchar())!= '\n' && limpar != EOF);
}

//função para obter valores int
int valorintpequeno (int minvalor , int maxvalor , char *mensagem ){
    int valor ;
    printf (mensagem);
    // faz um ciclo ate o valor que esta em valor ser diferente que 1 ou menor que o min ou maior que o maximo quando uma dessas 3 verifican-se ele repete
    while (scanf ("%d",&valor) !=1 || valor < minvalor || valor > maxvalor){
        printf ("Valor errado\n");
        printf (mensagem);
        //limpar o buffer
         limparbuffer ();
    }
    //limpar o buffer
      limparbuffer ();
    return valor;
}




//função para ler strings
void lerfrase(char *frase, int tamanho, char *mensagem) {
    printf(mensagem);  // Mostra a mensagem para o usuário
    if (fgets(frase, tamanho, stdin) != NULL) {
        size_t len = strlen(frase);  // Calcula o comprimento da string lida 
        if (len > 0 && frase[len - 1] == '\n') {  // Verifica se o último caractere é '\n'            
            frase[len - 1] = '\0';  // Substitui '\n' por '\0'           
        } else {
            limparbuffer();  // Limpa o buffer se a entrada excedeu o tamanho
        }
    } else {
        printf("Erro ao ler a entrada.\n");
        frase[0] = '\0';  // Garante que a string está vazia em caso de erro
    }
    
}

 
 //funação para vereficar o email do cliente
 void emailcheck2(char *email, int tamanho, char *mensagem) {
    char *arroba;
    char *ponto;
    int valido;

    do {
        valido = 1;  
        lerfrase(email, tamanho, mensagem);

        // Verifica se o email é muito pequeno
        if (strlen(email) < 5) {
            printf("\nO email é muito curto\n");
            valido = 0;
            continue;
        }

        // Procura '@' e o último '.'
        arroba = strchr(email, '@');
        ponto = strrchr(email, '.');

        if (arroba == NULL || ponto == NULL) {
            printf("\nNo email deve ter um '@' ou um '.'\n");
            valido = 0;
            continue;
        }


        // Verifica se '@' não é o primeiro caractere
        if (arroba == email) {
            printf("\nO email não pode começar com '@'\n");
            valido = 0;
            continue;
        }

        // Verifica se o domínio termina com ".com", ".pt", etc.
        if (strlen(ponto) < 3 || strlen(ponto) > 5) {
            printf("\nO emial deve ter um .com ou um .pt\n");
            valido = 0;
        }

    } while (!valido);
}
 
 
 
 

 //função para ler o tamanho da roupa
 void lertamanhoroupa(char *size){
    int i;
    printf("Digite o tamanho da roupa (XS, S, M, L, XL, XXL): ");
    scanf("%2s", size);
    for (int i = 0; size[i] != '\0'; i++) {
        if (size[i] >= 'a' && size[i] <= 'z') {
            size[i] -= 32; // Converter de minúsculo para maiúsculo
        }
    }
    if (strcmp(size, "XS") == 0 || strcmp(size, "S") == 0 ||
        strcmp(size, "M") == 0 || strcmp(size, "L") == 0 ||
        strcmp(size, "XL") == 0 || strcmp(size, "XXL") == 0) {
        printf("Tamanho válido: %s\n", size);
    } else {
        printf("Tamanho inválido. Tente novamente.\n");
    }
} 
// funções para registar o tempo 
 

     //funação para registar o dia
      int registoDia (){
         time_t dia = time(NULL);
        int dia_correto = localtime(&dia)->tm_mday;
        return dia_correto;
     }
    
     // função para obter o mes que é registado
     int registoMes (){
         time_t mes = time(NULL);
        int mes_correto = localtime(&mes)->tm_mon + 1;
        return mes_correto;
     }
     // função para obter o ano que é registado
      int registoAno (){
         time_t ano = time(NULL);
        int ano_correto = localtime(&ano)->tm_year + 1900;
        return ano_correto;
     }
      //funções para obter a hora que é registado 
      
       int registoHora (){
         time_t hora = time(NULL);
        int hora_correto = localtime(&hora)->tm_hour;
        return hora_correto;
     }
      //funções para obter os min que é registado
       int registoMin (){
           time_t min = time(NULL);
           int min_correto= localtime(&min)->tm_min;
           return min_correto;
       }
       //função para obter os seg que é registado
       int registoSeg(){
           time_t seg = time (NULL);
           int seg_correto =localtime(&seg)->tm_sec;
           return seg_correto;
       }
 
 
  