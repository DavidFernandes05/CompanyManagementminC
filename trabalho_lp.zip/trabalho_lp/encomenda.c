 /* 
 * File:   cliente.c
 * Author: David Fernandes
 *
 * Created on 28 de novembro de 2024, 11:31
 * @brief Neste ficheiro desenvolvo as funções para as encomendas.
 * Este ficheiro comtem as funções desenvolvidas para as encomendas tanto as funções do crud como as funções dos relatórios
 */


//incluir bibliotecas que vou precisar
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "input.h"
#include "encomenda.h" 
#include "produto.h"
#include "cliente.h"
#include <time.h>
#include <math.h>
//Função pata imprimir uma encomenda especifica
//em ultimo caso tirar a quantodade de produtos
   void Mostrar_Encomenda(encomenda enc) {
    printf("----------Informações sobre a encomenda %d -----------\n ID: %d \n Cliente: %d \n Taxa de com primento: %0.2f % \n Prioridade: %d \n Estado: %d \n Data de Registo: %d-%d-%d às %d:%d:%d \n Produtos: %d\n",enc.id_encomenda,
        enc.id_encomenda, enc.id_cliente, enc.taxa_cumprimento_encomenda,enc.prioridade_encomenda, enc.estado_da_encomenda,enc.data_reg.dia, enc.data_reg.mes, enc.data_reg.ano, 
        enc.data_reg.horas, enc.data_reg.minutos, enc.data_reg.segundos, enc.numero_produto); 
        int i;
        for (i = 0; i < enc.numero_produto; i++) {
            printf(" \n-----Info sobre os produtos da encomenda %d ------ \nId do produto: %d \n  Quantidade: %d\n",enc.id_encomenda, enc.produto[i].id_produto, 
                enc.produto[i].quantidade);
    }
}

   
    // Inicializar estrutura encomendas
    void inicializar_encomendas(Listaencomendas *encomendas,int capacidadeInicial) {
    encomendas->contador = 0;
    encomendas->capacidade=capacidadeInicial;// por a capacidade inicial a 10 caixas 
    encomendas->encomendas = malloc(capacidadeInicial*sizeof(encomenda));//cria 10 caixas para as encomendas
    if (encomendas->encomendas == NULL) {
        printf("Erro ao alocar memória para as encomendas.\n");
        exit(EXIT_FAILURE);
    }
}

   
   // Libertar memória alocada para encomendas
    void liberar_encomendas(Listaencomendas *encomendas) {
    int i;
    for (i = 0; i < encomendas->contador; i++) {
        free(encomendas->encomendas[i].produto); // Liberta  memória dos itens
        encomendas->encomendas[i].produto = NULL; // Define o apontador como NULL
    }
    free(encomendas->encomendas); // Liberta memória das encomendas
    encomendas->encomendas = NULL; // Define o apontador como NULL
}

 //apagar uma encomenda
    void apagar_Dados_Encomenda(encomenda *enc) {
        if (enc->produto != NULL) {
        free(enc->produto);  // apaga a memória dos itens
        enc->produto = NULL; // Define o apontador como NULL 
    }
        enc->id_encomenda = 0;
        enc->id_cliente = 0;
        enc->data_reg.ano = 0;
        enc->data_reg.mes = 0;
        enc->data_reg.dia = 0;
        enc->data_reg.horas = 0;
        enc->data_reg.minutos = 0;
        enc->data_reg.segundos = 0;
        enc->prioridade_encomenda = PRIORIDADE_BAIXA;
        enc->estado_da_encomenda = ESTADO_ENCOMENDA_ABERTA;
        enc->taxa_cumprimento_encomenda = 0.0;
        enc->numero_produto = 0;
}
 //função para procurar uma encomenda
    int procurar_Encomenda(Listaencomendas encomendas, int id_encomenda) {
    int i;
    for (i = 0; i < encomendas.contador; i++) {
        if (encomendas.encomendas[i].id_encomenda == id_encomenda) {
            //retorna o id da encomenda
            return i;
        }
    }
    return -1;
}
//função para inserir uma encomenda
    //apagar se der errado
    int inserir_Encomenda(Listaencomendas *encomendas) {
       
    int i;
    //verifica se há espaço para uma encomenda
    if (encomendas->contador >= MAX_ENCOMENDAS) {
        printf("Erro: Limite de encomendas atingido.\n");
        return -1;
    }
    encomenda nova_encomenda;
    // id da encomenda
    nova_encomenda.id_encomenda = encomendas->contador + 1; 
    //id do cliente que fez a encomenda
    //apagar se der errado
    nova_encomenda.id_cliente = valorintpequeno(NUM_MIN_CLIENTES,NUM_MAX_CLIENTES,MSG_OBTER_ID_CLI);
    //Registar a data em que a encomenda foi criada
    nova_encomenda.data_reg.ano=registoAno();
    nova_encomenda.data_reg.mes=registoMes();
    nova_encomenda.data_reg.dia=registoDia();
    nova_encomenda.data_reg.horas=registoHora();
    nova_encomenda.data_reg.minutos=registoMin();
    nova_encomenda.data_reg.segundos=registoSeg();
    //Defenir a prioridade da encomenda
    nova_encomenda.prioridade_encomenda = valorintpequeno(PRIORIDADE_BAIXA,PRIORIDADE_ALTA,OBTER_PRIORIDADE_ECONMENDA);
    //A encomneda quando criada fica aberta
    nova_encomenda.estado_da_encomenda = ESTADO_ENCOMENDA_ABERTA; 
    //A encomenda quando criada fica com  uma taxa de comprimento0 de 0 
    nova_encomenda.taxa_cumprimento_encomenda = 0.0;
    //pedir ao utilizador quantos produtos vão estar na encomenda
    nova_encomenda.numero_produto = valorintpequeno(MIN_ITENS_ENCOMENDA,MAX_ITENS_ENCOMENDA,MSG_OBTER_ITNS);
    //memoria dinamica para os produtos
    nova_encomenda.produto = (Produto_encomenda*)malloc(nova_encomenda.numero_produto * sizeof(Produto_encomenda));
    //verifica se alocou memoria dinamica para os produtos
    if (nova_encomenda.produto == NULL) {
        printf("Erro ao alocar memória para os itens.\n");
        return -1;
    }
    //Pede o id do produto que deseja adicionar na encomenda 
    for (i = 0; i < nova_encomenda.numero_produto; i++) {
        nova_encomenda.produto[i].id_produto = valorintpequeno(MIN_ID_PRODUTO,MAX_ID_PRODUTO,MSG_ID_PRODUTO);
        nova_encomenda.produto[i].quantidade= valorintpequeno(MIN_ITENS_ENCOMENDA,MAX_ITENS_ENCOMENDA,MSG_OBTER_QNTD);
       
    }

    encomendas->encomendas[encomendas->contador] = nova_encomenda;
    encomendas->contador++;
    return 0;
    
}

//atualizar encomenda
    void atualizar_Encomenda(encomenda *enc) {
    //nesta função nos voltamos a pedir oa utilizador a prioidade
    //o estado da encomenda e a taxa de comprimento
    enc->prioridade_encomenda = valorintpequeno(PRIORIDADE_BAIXA,PRIORIDADE_ALTA,OBTER_PRIORIDADE_ECONMENDA);
    enc->estado_da_encomenda = valorintpequeno(ESTADO_ENCOMENDA_ABERTA,ESTADO_ENCOMENDA_FINALIZADA,OBTER_ESTADO_ENCOMENDA);
    //verificar se o estado da encomenda for finalizado é porque a taxa de cumprimento esta a 100
    if (enc->estado_da_encomenda == ESTADO_ENCOMENDA_FINALIZADA) {
        enc->taxa_cumprimento_encomenda = 100.0;
    //se nao a encomenda ainda esta em produção e pede a taxa
    } else if (enc->estado_da_encomenda == ESTADO_ENCOMENDA_PRODUCAO) {
        enc->taxa_cumprimento_encomenda = valorintpequeno(MIN_TAXACUPRIMENTO_ENCOMENDA,MAX_TAXACUPRIMENTO_ENCOMENDA,MSG_OBTER_TAXACUMPRIMENTO);
    } else {
        enc->taxa_cumprimento_encomenda = 0.0;
    }
}
   
  
    
    //Verificação para ver se da para inserir uam encomenda
    //remover se estiver
    void criar_Encomendas(Listaencomendas *encomendas/*,Listaclientes *lista*/ ) {
    // Verifica se tem espaço para mais uma encomenda
    if (encomendas->contador >= MAX_ENCOMENDAS) {
        puts("Erro: Limite de encomendas atingido.");
        return;
    }
    
    //Realoca memória dinamicamente 
    //quando necessario ele dobra o espaço para poder fazer mais encomendas
    encomenda *memoria_encomenda = realloc(encomendas->encomendas, (encomendas->contador +1) * sizeof(encomenda));
    if (memoria_encomenda == NULL) {
        puts("Erro ao realocar memória para as encomendas.");
        return;
    }
    //atualizar o endereço
    encomendas->encomendas = memoria_encomenda;
    //chamar a função para criar uma encomenda
    if (inserir_Encomenda(encomendas) == -1) {
        puts("Erro: Encomenda já existe.");
    } else {
        puts("Encomenda inserida com sucesso.");
    }
}

    //função para procurar uma encomenda
    void procurar_Encomendas(Listaencomendas encomendas) {
        //id_encomenda vai receber o id que queremos procurar
    int id_encomenda = procurar_Encomenda(encomendas, valorintpequeno(MIN_ENCOMENDAS,MAX_ENCOMENDAS,MSG_ID_ENCOMENDA));
    // se a encomenda existir ele chama a função de imprimir a encomenda com esse indece
    if (id_encomenda != -1) {
        Mostrar_Encomenda(encomendas.encomendas[id_encomenda]);
    } else {
        puts("Encomenda não encontrada!!");
    }
}

    //Função para atualizar uma encomenda
    void att_Encomendas(Listaencomendas *encomendas) {
        //id_encomenda vai receber o id que queremos atualizar
    int id_encomenda = procurar_Encomenda(*encomendas, valorintpequeno(MIN_ENCOMENDAS,MAX_ENCOMENDAS,MSG_ID_ENCOMENDA));
    //Se a encomenda existir ele chama atualizar encomenda com a encomenda do indece
    if (id_encomenda != -1) {
        // é um endereço pois vamos alterar
        atualizar_Encomenda(&encomendas->encomendas[id_encomenda]);
    } else {
        puts("Encomenda não encontrada!!");
    }
}
    
    //Função para remover encomendas 
    void Rmv_Encomendas(Listaencomendas *encomendas) {
    int i, id_encomenda = procurar_Encomenda(*encomendas,valorintpequeno(MIN_ENCOMENDAS,MAX_ENCOMENDAS,MSG_ID_ENCOMENDA));
    //
    if (id_encomenda != -1) {
        //este ciclo "puxa as encomendas todas para o lugar da encomenda removida prenchendo o espaço que falta"
        for (i = id_encomenda; i < encomendas->contador - 1; i++) {
            encomendas->encomendas[i] = encomendas->encomendas[i + 1];
        }
        //chama a função apagar dados para limpar os dados da encomenda
        apagar_Dados_Encomenda(&encomendas->encomendas[i]);
        //diminui 1 no contador
        encomendas->contador--;
        puts("A encomenda foi removida com sucesso!!!!");
    } else {
        puts("Encomenda não encontrada!!");
    }
}    
   //Funções para os relatorios das encomendas
   //Função para listar as encomendas pelo estado
    void listar_Estado_encomenda(Listaencomendas *encomendas, int estado_da_encomenda) {
    int i;
    if (encomendas->contador==0){
        printf("Lista de encomendas vazia!!!");
    }
    // percorre o array das encomendas e se a encomenda tiver o estado que quer lista essa encomenda
    for (i = 0; i < encomendas->contador; i++) {
        if (encomendas->encomendas[i].estado_da_encomenda == estado_da_encomenda) {
            Mostrar_Encomenda(encomendas->encomendas[i]);
        }
    }
}
    //comentar apartir daqui 
    
    //função para listar as encomendas por a prioridade
    void listar_encomendas_prioridade(Listaencomendas encomendas, int prioridade_encomenda) {
    int i;
    //verifica se a encomendas
     if (encomendas.contador==0){
        printf("Lista de encomendas vazia!!!");
    }
    //imprime as encomendas que tiverem o estado que nos metermos
    for (i = 0; i < encomendas.contador; i++) {
        if (encomendas.encomendas[i].prioridade_encomenda == prioridade_encomenda) {
            Mostrar_Encomenda(encomendas.encomendas[i]);
        }
    }
}  
    //Função para listar as encomendas todas
    void Ver_Todas_encomendas(Listaencomendas *encomendas) {
        printf("Relatório Total de Encomendas:\n");
        //mostra as encomedas todas feitas no sistema
        for (int i = 0; i < encomendas->contador; i++) {
             Mostrar_Encomenda(encomendas->encomendas[i]);
    }
}
 
//algoritmo 
    //1->listar por prioridade
    //2->Tempos de finalização das encomendas
    
    void Listar_encomendas_auto(Listaencomendas *encomendas) {
    int i;

    // Verificar se a lista está vazia
    if (encomendas->contador == 0) {
        printf("Nenhuma encomenda encontrada.\n");
        return;
    }

    // Listar encomendas com prioridade 3
    for (i = 0; i < encomendas->contador; i++) {
        if (encomendas->encomendas[i].prioridade_encomenda == 3) {
            Mostrar_Encomenda(encomendas->encomendas[i]);
        }
    }

    // Listar encomendas com prioridade 2
    for (i = 0; i < encomendas->contador; i++) {
        if (encomendas->encomendas[i].prioridade_encomenda == 2) {
            Mostrar_Encomenda(encomendas->encomendas[i]);
        }
    }

    // Listar encomendas com prioridade 1
    for (i = 0; i < encomendas->contador; i++) {
        if (encomendas->encomendas[i].prioridade_encomenda == 1) {
            Mostrar_Encomenda(encomendas->encomendas[i]);
        }
    }
}
    
    
    
    
    
    
//função para calculartempodaencomenda    
void calcularTempoEncomenda(Listaencomendas *enc, categoria_produtos *categorias) {
    int tempo_total = 0; // Tempo total de produção da encomenda
    int i, j;

    // Itera por todos os itens na encomenda
    for (i = 0; i < enc->encomendas->numero_produto; i++) { 
        if (enc->encomendas[i].estado_da_encomenda == 3){
        int id_produto = enc->encomendas->produto[i].id_produto; // ID do produto
        int quantidade = enc->encomendas->produto[i].quantidade; // Quantidade do produto

        // Procura o produto no catálogo de categorias
        for (j = 0; j < categorias->contador; j++) {
            if (categorias->produtos[j].id_produto == id_produto) {
                // Adiciona o tempo de produção do produto, multiplicado pela quantidade
                tempo_total += categorias->produtos[j].maquina_tempo_execucao.tempo_execucao * quantidade;
                break; // Sai do loop quando o produto é encontrado
            }
        }
        printf("A encomenda %d demorou %d min.",enc->encomendas[i].id_encomenda,tempo_total);
    }else{
        printf("Não há encomendas finalizadas na lista!!!!");
    }
    }

    
}
/*
    //encomendas->encomendas[i].estado_da_encomenda == estado_da_encomenda
 void gerarRelatorioProducao(Listaencomendas *encomendas, int total_encomendas, categoria_produtos *categorias) {
    int i;
    int tempo_acumulado = 0; // Inicializa o tempo acumulado de produção

    // Itera por todas as encomendas
    for (i = 0; i < total_encomendas; i++) {
        // Verifica se a encomenda está em produção (estado 1)
        if ( encomendas->encomendas[i].estado_da_encomenda== ESTADO_ENCOMENDA_PRODUCAO) {
            // Calcula o tempo estimado para a encomenda atual
            int tempo_encomenda = calcularTempoEncomenda(&encomendas[i], categorias);
            tempo_acumulado += tempo_encomenda; // Atualiza o tempo acumulado

            // Imprime as informações da encomenda
            printf("Encomenda ID: %d | Prioridade: %d | Data Criação: %d/%d/%d\n",
                   encomendas->encomendas[i].id_encomenda, encomendas->encomendas[i].prioridade_encomenda,
                   encomendas->encomendas[i].data_reg.dia, encomendas->encomendas[i].data_reg.mes, encomendas->encomendas[i].data_reg.ano);
            printf("Tempo Estimado: %d minutos | Tempo estimado para todas as encomendas estarem prontas: %d minutos\n\n", tempo_encomenda, tempo_acumulado);
        }
    }
}   
    */
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
   
 /*  
    void calcular_tempo_encomenda_fi(Listaencomendas *encomendas,categoria_produtos *produtos){
        int i;
        int tempo = 0;
        for (i=0;i<encomendas->contador;i++){
            if (encomendas->encomendas[i].estado_da_encomenda == ESTADO_ENCOMENDA_FINALIZADA){
                tempo = encomendas->encomendas[i].tempo_exe = produtos->produtos[i].maquina_tempo_execucao.tempo_execucao*encomendas->encomendas[i].produto->quantidade;
                printf ("O tempo de produção da encomenda %d foi de %d min\n",encomendas->encomendas[i].id_encomenda,tempo);
                
            }else{
                printf("Não há encomendas finalizadas!!\n");
            }
        }
    }
    
       /*
    void calcular_tempo_encomenda_fi(Listaencomendas *encomendas, categoria_produtos *produtos) {
    int i, j;

    for (i = 0; i < encomendas->contador; i++) {
        if (encomendas->encomendas[i].estado_da_encomenda == ESTADO_ENCOMENDA_FINALIZADA) {
            int tempo_total = 0;
            printf("ola");
            // Iterar pelos produtos da encomenda
            for (j = 0; j < encomendas->encomendas[i].produto->quantidade; j++) {
                Produto_encomenda *produto_encomenda = &encomendas->encomendas[i].produto[j];

                // Procurar o tempo de execução do produto na lista de produtos
                int k;
                for (k = 0; k < produtos->contador; k++) {
                    printf("ola");
                    if (produtos->produtos[k].id_produto == produto_encomenda) {
                        tempo_total += produtos->produtos[k].maquina_tempo_execucao.tempo_execucao * produto_encomenda->quantidade;
                        break;
                    }
                }
            }

            printf("O tempo de produção da encomenda %d foi de %d min\n", encomendas->encomendas[i].id_encomenda, tempo_total);
        } else {
            printf("A encomenda %d não está finalizada e não pode ser processada.\n", encomendas->encomendas[i].id_encomenda);
        }
    }
}
*/
    
    
    

//testes a partir daqui
    
    
 
    
    
    
 /* 
void calcular_Tempo_Producao(Listaencomendas *encomendas) {
    for (int i = 0; i < encomendas->contador; i++) {
        if (encomendas->encomendas[i].estado_da_encomenda == ESTADO_ENCOMENDA_FINALIZADA) {
            struct tm tempo_inicio = {0}; // Inicializa com zeros
            tempo_inicio.tm_year = encomendas->encomendas[i].data_reg.ano - 1900;
            tempo_inicio.tm_mon = encomendas->encomendas[i].data_reg.mes - 1;
            tempo_inicio.tm_mday = encomendas->encomendas[i].data_reg.dia;
            tempo_inicio.tm_hour = encomendas->encomendas[i].data_reg.horas;
            tempo_inicio.tm_min = encomendas->encomendas[i].data_reg.minutos;
            tempo_inicio.tm_sec = encomendas->encomendas[i].data_reg.segundos;

            printf("Data de início: %d-%d-%d %d:%d:%d\n", 
                tempo_inicio.tm_year + 1900, tempo_inicio.tm_mon + 1, tempo_inicio.tm_mday, 
                tempo_inicio.tm_hour, tempo_inicio.tm_min, tempo_inicio.tm_sec);

            struct tm tempo_fim = {0}; // Inicializa com zeros
            tempo_fim.tm_year = encomendas->encomendas[i].data_finalizacao.ano - 1900;
            tempo_fim.tm_mon = encomendas->encomendas[i].data_finalizacao.mes - 1;
            tempo_fim.tm_mday = encomendas->encomendas[i].data_finalizacao.dia;
            tempo_fim.tm_hour = encomendas->encomendas[i].data_finalizacao.horas;
            tempo_fim.tm_min = encomendas->encomendas[i].data_finalizacao.minutos;
            tempo_fim.tm_sec = encomendas->encomendas[i].data_finalizacao.segundos;

            printf("Data de finalização: %d-%d-%d %d:%d:%d\n", 
                tempo_fim.tm_year + 1900, tempo_fim.tm_mon + 1, tempo_fim.tm_mday, 
                tempo_fim.tm_hour, tempo_fim.tm_min, tempo_fim.tm_sec);

            time_t t_inicio = mktime(&tempo_inicio);
            time_t t_fim = mktime(&tempo_fim);

            if (t_inicio == -1 || t_fim == -1) {
                printf("Erro ao converter as datas para time_t.\n");
            } else if (t_fim < t_inicio) {
                printf("Erro: A data de finalização é anterior à data de início para a encomenda %d.\n", encomendas->encomendas[i].id_encomenda);
            } else {
                double segundos = difftime(t_fim, t_inicio);
                printf("Encomenda %d levou %.0f segundos para produção.\n", encomendas->encomendas[i].id_encomenda, segundos);
            }
        }
    }
}





    
/*
    void calcular_Tempo_Medio_Producao(Listaencomendas *encomendas) {
    double total_tempo = 0;
    int total_encomendas = 0;

    for (int i = 0; i < encomendas->contador; i++) {
        if (encomendas->encomendas[i].estado_da_encomenda == ESTADO_ENCOMENDA_FINALIZADA) {
            // Inicializa a estrutura tm para data de criação
            struct tm tm_inicio = {0};
            tm_inicio.tm_year = encomendas->encomendas[i].data_criacao.ano - 1900;
            tm_inicio.tm_mon = encomendas->encomendas[i].data_criacao.mes - 1;
            tm_inicio.tm_mday = encomendas->encomendas[i].data_criacao.dia;
            tm_inicio.tm_hour = encomendas->encomendas[i].data_criacao.horas;
            tm_inicio.tm_min = encomendas->encomendas[i].data_criacao.minutos;
            tm_inicio.tm_sec = encomendas->encomendas[i].data_criacao.segundos;

            // Cria o tempo de início
            time_t tempo_inicio = mktime(&tm_inicio);
            if (tempo_inicio == -1) {
                printf("Erro ao calcular o tempo de início para a encomenda %d\n", encomendas->encomendas[i].id_encomenda);
                continue;
            }

            // Inicializa a estrutura tm para data de finalização
            struct tm tm_fim = {0};
            tm_fim.tm_year = encomendas->encomendas[i].data_finalizacao.ano - 1900;
            tm_fim.tm_mon = encomendas->encomendas[i].data_finalizacao.mes - 1;
            tm_fim.tm_mday = encomendas->encomendas[i].data_finalizacao.dia;
            tm_fim.tm_hour = encomendas->encomendas[i].data_finalizacao.horas;
            tm_fim.tm_min = encomendas->encomendas[i].data_finalizacao.minutos;
            tm_fim.tm_sec = encomendas->encomendas[i].data_finalizacao.segundos;

            // Cria o tempo de finalização
            time_t tempo_fim = mktime(&tm_fim);
            if (tempo_fim == -1) {
                printf("Erro ao calcular o tempo de finalização para a encomenda %d\n", encomendas->encomendas[i].id_encomenda);
                continue;
            }

            // Calcular a diferença em segundos
            double segundos = difftime(tempo_fim, tempo_inicio);
            total_tempo += segundos;
            total_encomendas++;
        }
    }

    // Verifique se houve encomendas finalizadas
    if (total_encomendas > 0) {
        double tempo_medio = total_tempo / total_encomendas;
        printf("Tempo médio de produção: %.0f segundos.\n", tempo_medio);
    } else {
        printf("Nenhuma encomenda finalizada para calcular o tempo médio.\n");
    }
}

*/
