/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cFiles/main.c to edit this template
 */

/**
* @file main.c
* @author David Fernandes
* @date 27-11-2024
*
*
* @brief Programa onde roda as funções todas.
*
* Neste ficheiro main.c esta basicamente a chamar as funções das bibliotecas que inclui.
*/
#include <stdio.h>
#include <stdlib.h>
#include "cliente.h"
#include "encomenda.h"
#include"maquina.h"
#include "menu.h"
 
int main() {
    Menuprincipal();
}
