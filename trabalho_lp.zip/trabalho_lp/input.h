/* 
 * File:   input.h
 * Author: David Fernandes
 *
 * Created on 28 de novembro de 2024, 11:31
 * @brief Neste ficheiro vou declarar as funções de intput.
 * Este ficheiro comtem as funções para depois no input.c desenvolve-las estas funções servem para poupar algum trabalho a desenvolver as outras partes. 
 */

#ifndef INPUT_H
#define INPUT_H
#include <stdbool.h>
#define MAX_SIZE 3 

#ifdef __cplusplus
extern "C" {
#endif
    //funções para obter valores
    //função para obter inteiro ja com pré verificações 
    int valorintpequeno (int minvalor , int maxvalor , char *mensagem);
    //função para limpar o buffer
    void limparbuffer();
    //função para ler uma string
    void lerfrase (char *frase ,int tamanho , char *mensagem);
    //função para vereficar o email
    void emailcheck2 (char *email, int tamanho ,char *mensagem);
    //função para ler o tamanho da peça de roupa
    void lertamanhoroupa(char *size);
    //funções para o regsito 
    //função para registar o mes atual
    int registoMes();
    //função para registar o dia atual
    int registoDia();
    //função para registar o ano atual
    int registoAno();
    //função para registar a hora atual
    int registoHora();
    //função para registar o minuto atual
    int registoMin();
    //função para registar o segundo atual
    int registoSeg();
     
    


#ifdef __cplusplus
}
#endif

#endif /* INPUT_H */

