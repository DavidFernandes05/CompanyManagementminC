/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cFiles/main.c to edit this template
 */

/* 
 * File:   maquina.c
 * Author: ricardo
 *
 * Created on 9 de dezembro de 2024, 11:49
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "input.h"
#include "produto.h"
#include "maquina.h"
#include <float.h>


void inicializar_Maquinas(MaquinasGeral *maquinas, int capacidade_inicial) {
    // Verifica se a capacidade inicial é válida (se for menor ou igual a 0 é inválido)
    if (capacidade_inicial <= 0) {
        // Exibe uma mensagem de erro e usa o valor padrão definido como 10
        printf("Capacidade inicial inválida, será ultilizado um valor padrão de 8.\n");
        capacidade_inicial = 8; // Define a capacidade inicial como 8
    }

    maquinas->contMaq = 0; // Inicializa o contador de máquinas
    // Define a capacidade máxima das máquinas com o valor informado ou o valor padrão
    maquinas->listaMaquinas = (maquina * ) malloc (capacidade_inicial * sizeof(maquina));
    // Verifica se a alocação de memória foi bem-sucedida
    if (maquinas->listaMaquinas == NULL) {
        printf("Erro ao alocar memória para as máquinas.\n");
        exit(EXIT_FAILURE); // Encerra o programa se a alocação falhar para evitar problemas
    }

    // Inicializa os valores das máquinas de forma padrão
    int i;
    for (i = 0; i < capacidade_inicial; i++) {
        maquinas->listaMaquinas[i].idMaquina = 0;
        strcpy(maquinas->listaMaquinas[i].nomeMaquina, " ");
        maquinas->listaMaquinas[i].tipoMaquina = BORDADO; // Atribui um tipo padrão 
        
    }
}


void libertar_Memoria_Maquinas(MaquinasGeral *maquina) {
    if (maquina->listaMaquinas != NULL) {
        free(maquina->listaMaquinas);  // Liberta a memória alocada
        maquina->listaMaquinas = NULL; // Define o ponteiro como NULL após a liberação
    }
}

void realocar_Memoria_Maquinas(MaquinasGeral *Maquina) {
    maquina *temp = realloc(Maquina->listaMaquinas, (Maquina->contMaq + 1) * sizeof(Maquina));
    if (temp == NULL) {
        printf("Erro ao realocar memória para a lista de máquinas!\n");
        exit(1);  // Finaliza o programa caso a realocação falhe
    }
    Maquina->listaMaquinas = temp;  // Atualiza o ponteiro se a realocação for bem-sucedida
}




//Imprime os dados da máquina 
void imprimir_Maquina(maquina maquina) {
    switch(maquina.tipoMaquina){
        case 1:
            printf ("\n ID: %d \n Nome da Máquina: %s \n Tipo de Máquina: Bordado ", maquina.idMaquina, maquina.nomeMaquina);
            break;
        case 2:
            printf ("\n ID: %d \n Nome da Máquina: %s \n Tipo de Máquina: Acabamento ", maquina.idMaquina, maquina.nomeMaquina);
            break;
        case 3:
            printf ("\n ID: %d \n Nome da Máquina: %s \n Tipo de Máquina: Embalagem  ", maquina.idMaquina, maquina.nomeMaquina);
            break;
    } 


}

//Apaga os dados da máquina
void apagar_Informacao_Maquina(maquina *maquina) {
    maquina->idMaquina = 0;
    strcpy(maquina->nomeMaquina, "");
    maquina->tipoMaquina=0;
}

//Localiza a máquina na lista pelo ID
int procurar_Maquina(MaquinasGeral maquina, int idMaquina){
        int i;
        for(i = 0; i < maquina.contMaq; i++) {
            if(maquina.listaMaquinas[i].idMaquina == idMaquina) {
                return i;  // Retorna o índice da máquina
            }
        }
    return -1;  // Retorna -1 se a máquina não for encontrada
}

// Função para atualizar as informações de uma máquina
void atualizar_Maquina(maquina *maquina){
    maquina->idMaquina= valorintpequeno(MINIMO_ID_MAQUINA, MAXIMO_ID_MAQUINA, "Insira o ID da máquina: ");
    lerfrase((*maquina).nomeMaquina,MAXIMO_NOME_MAQUINAS, "Insira o nome da máquina: ");
    TipoMaquina tipoMaquina; 
    tipoMaquina = (TipoMaquina) valorintpequeno(1, 3, "Insira o tipo da Máquina:\n 1 - Bordado,\n 2 - Acabamento,\n 3 - Embalagem: ");
}

// Função para inserir uma nova máquina na lista
int inserir_Maquina(MaquinasGeral *Maquina){
    // Verifica se atingiu o limite de máquinas
    if (Maquina->contMaq >= MAX_MAQUINAS) {
        printf("Erro!: O número máximo permitido de máquina foi atingido.\n");
        return -1;  // Retorna erro se o limite for atingido
    }

    // Se a lista de máquinas está vazia (contMaq == 0), aloca memória para a primeira máquina
    if (Maquina->contMaq == 0) {
        Maquina->listaMaquinas = (maquina *)malloc(sizeof(maquina)); // Aloca memória para a primeira máquina
        if (Maquina->listaMaquinas == NULL) {
            printf("Erro ao alocar memória para a máquina.\n");
            return -1;  // Retorna erro se falhar a alocação
        }
    } else {
        // Realoca memória para adicionar uma nova máquina
        maquina *novalista = (maquina *)realloc(Maquina->listaMaquinas, (Maquina->contMaq + 1) * sizeof(maquina));
        if (novalista == NULL) {
            printf("Erro ao realocar memória para a máquina.\n");
            return -1;  // Retorna erro se falhar a realocação
        }
        Maquina->listaMaquinas = novalista;  // Atualiza o ponteiro para a lista de máquinas
    }

    // Solicita o ID da nova máquina e verifica se já existe
    int idMaquina = valorintpequeno(MINIMO_ID_MAQUINA, MAXIMO_ID_MAQUINA, "Insira o ID da Máquina: ");
    if (procurar_Maquina(*Maquina, idMaquina) != -1) {  // Verifica se a máquina com esse ID já existe
        printf("Erro: Esse ID da máquina já existe.\n");
        return -1;
    }

    // Insere a nova máquina
    Maquina->listaMaquinas[Maquina->contMaq].idMaquina = idMaquina;
    lerfrase(Maquina->listaMaquinas[Maquina->contMaq].nomeMaquina, MAXIMO_NOME_MAQUINAS, "Insira o nome da máquina: "); 
    
    TipoMaquina tipoMaquina = (TipoMaquina)valorintpequeno(1, 3, "Insira o tipo de Máquina:\n 1 - Bordado,\n 2 - Acabamento,\n 3 - Embalagem: "); 
    Maquina->listaMaquinas[Maquina->contMaq].tipoMaquina = tipoMaquina;

    // Incrementa o contador de máquinas
    Maquina->contMaq++;

    return Maquina->contMaq;  // Retorna o número de máquinas após a inserção
}

//CRUD (Funções Principais)

//Criar-adicionar

// Função para adicionar uma máquina na lista, com verificação de capacidade
void adicionar_Maquinana_Lista(MaquinasGeral *maquina) {
    if (maquina->contMaq < MAX_MAQUINAS) {  // Verifica se ainda há espaço na lista
        if (inserir_Maquina(maquina) == -1) {
            printf("Erro: Não foi possível adicionar a máquina.");
        } else {
            printf("Máquina adicionada com sucesso.");
        }
    } else {
        printf("Erro: A lista de máquinas já se encontra cheia!");
    }
}

// Função para ler e imprimir informações de uma máquina específica
 void ler_Maquinana_Lista(MaquinasGeral maquina){
         int idMaquina = procurar_Maquina(maquina, valorintpequeno(MINIMO_ID_MAQUINA, MAXIMO_ID_MAQUINA,"Insira o ID da Máquina: "));
            if(idMaquina!=-1){
                imprimir_Maquina(maquina.listaMaquinas[idMaquina]);
            }else{
                printf("O ID não corresponde a nenhuma máquina!");
            }  
    }
  

// Função para atualizar uma máquina existente na lista
void atualizar_Maquinana_Lista(MaquinasGeral *maquina){
    int idMaquina= procurar_Maquina(*maquina, valorintpequeno(MINIMO_ID_MAQUINA,MAXIMO_ID_MAQUINA,"Insira qual o ID da máquina que pretende atualizar: "));
      
    if(idMaquina!=-1){
         atualizar_Maquina(&maquina->listaMaquinas[idMaquina]);
            
    }else{
        printf("Erro: A máquina não está registada na lista! ");
    }
    
}


// Função para remover uma máquina da lista e ajustar a memória alocada
void remover_Maquinana_Lista(MaquinasGeral *Maquina) {
    int i;
    // Obtém o ID da máquina que deseja remover
    int idMaquina = procurar_Maquina(*Maquina, valorintpequeno(MINIMO_ID_MAQUINA, MAXIMO_ID_MAQUINA, "Insira o ID da máquina que deseja remover: "));
    
    if (idMaquina != -1) {
        // Apaga os dados da máquina a ser removida
        apagar_Informacao_Maquina(&Maquina->listaMaquinas[idMaquina]);
        
        // Reorganiza a lista para remover o "buraco" criado pela remoção
        for (i = idMaquina; i < Maquina->contMaq - 1; i++) {
            Maquina->listaMaquinas[i] = Maquina->listaMaquinas[i + 1];
        }
        
        // Reduz o contador de máquinas
        Maquina->contMaq--;
        
        // Se houver máquinas na lista, realoca a memória
        if (Maquina->contMaq > 0) {
            maquina *novaLista = (maquina *)realloc(Maquina->listaMaquinas, Maquina->contMaq * sizeof(maquina));
            
            // Verifica se a realocação foi bem-sucedida
            if (novaLista == NULL) {
                printf("Erro ao realocar memória para a lista de máquinas.\n");
                return;
            }
            
            Maquina->listaMaquinas = novaLista;
        } else {
            // Caso não haja mais máquinas, libera a memória
            free(Maquina->listaMaquinas);
            Maquina->listaMaquinas = NULL;
        }
        
        printf("Máquina removida com sucesso.\n");
    } else {
        printf("Erro: A máquina não existe ou não está registrada. Impossível remover.");
    }
}

// Função para listar as máquinas da lista
void listar_Maquinas(MaquinasGeral *maquina) {
    if (maquina->contMaq > 0) {
        int i;
        for (i = 0; i < maquina->contMaq; i++) {
            imprimir_Maquina(maquina->listaMaquinas[i]); 
        }
    } else {
        printf("Erro!: Lista vazia, escolha outra opção!");
    }
}

// Relatório de máquinas mais utilizadas
void maquinas_Mais_Utilizadas(MaquinasGeral maquina) {
    printf("Máquinas mais utilizadas:\n"); 
    int i;
    for (i = 0; i < maquina.contMaq; i++) { 
        printf("ID: %d | Nome: %s ", maquina.listaMaquinas[i].idMaquina, maquina.listaMaquinas[i].nomeMaquina );
               
    }
}

// Relatório de tempo médio de produção por máquina
void tempo_Medio_Producao(MaquinasGeral *maquina, categoria_produtos *categoria) {
    int i;
    for(i = 0; i < maquina->contMaq; i++) {
        int idMaquina = maquina->listaMaquinas[i].idMaquina;
        int totalTempo = 0;
        int totalProdutos = 0;
        int j;
        for (j = 0; j < categoria->contador; j++) {
            if (categoria->produtos[j].maquina_tempo_execucao.id_maquina == idMaquina) {
                totalTempo += categoria->produtos[j].maquina_tempo_execucao.tempo_execucao;
                totalProdutos++;
            }
        }

        if(totalProdutos > 0) {
            float tempoMedio = (float) totalTempo / totalProdutos;
            printf("Máquina ID %d - Tempo Médio de Produção: %.2f\n", idMaquina, tempoMedio);
        } else {
            printf("Máquina ID %d - Nenhum produto produzido.\n", idMaquina);
        }
    }
}

// Relatório de tempo máximo e mínimo de produção por máquina
void tempo_Maximo_Minimo_Producao(MaquinasGeral *maquina, categoria_produtos *categoria) {
    int i;
    for(i = 0; i < maquina->contMaq; i++) {
        int idMaquina = maquina->listaMaquinas[i].idMaquina;
        const char *nomeMaquina = maquina->listaMaquinas[i].nomeMaquina;
        TipoMaquina tipo = maquina->listaMaquinas[i].tipoMaquina;

        float tempoMaximo = 0.1;
        float tempoMinimo = FLT_MAX;
        int encontrouProdutos = 0;

        const char *nomeTipo;
        if (tipo == BORDADO) {
            nomeTipo = "BORDADO";
        } else if (tipo == ACABAMENTO) {
            nomeTipo = "ACABAMENTO";
        } else {
            nomeTipo = "EMBALAGEM";
        }
        int j;
        for(j = 0; j < categoria->contador; j++) {
            if(categoria->produtos[j].maquina_tempo_execucao.id_maquina == idMaquina) {
                float tempoAtual = categoria->produtos[j].maquina_tempo_execucao.tempo_execucao;

                if(tempoAtual > tempoMaximo) {
                    tempoMaximo = tempoAtual;
                }
                if(tempoAtual < tempoMinimo) {
                    tempoMinimo = tempoAtual;
                }

                encontrouProdutos = 1;
            }
        }

        printf("Máquina: %s (ID %d, Tipo: %s)\n", nomeMaquina, idMaquina, nomeTipo);
        if(encontrouProdutos) {
            printf("Tempo Máximo de Produção: %.2f\n", tempoMaximo);
            printf("Tempo Mínimo de Produção: %.2f\n", tempoMinimo);
        } else {
            printf("Nenhum produto produzido.\n");
        }
    }
}