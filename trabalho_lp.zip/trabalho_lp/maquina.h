/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cFiles/file.h to edit this template
 */

/* 
 * File:   maquina.h
 * Author: ricar
 *
 * Created on 15 de dezembro de 2024, 11:48
 */

#ifndef MAQUINA_H
#define MAQUINA_H

#include "produto.h"
#ifndef MÁQUINA_H
#define MÁQUINA_H
#define MAX_MAQUINAS 10
#define MINIMO_NOME_MAQUINAS 5
#define MAXIMO_NOME_MAQUINAS 20
#define MINIMO_TIPO 2
#define MAXIMO_TIPO 50
#define MINIMO_ID_MAQUINA 1
#define MAXIMO_ID_MAQUINA 999




#define MAQUINA1 BORDADO
#define MAQUINA2 ACABAMENTO
#define MAQUINA3 EMBALAGEM


    
//Tipos de Máquinas 
    typedef enum {BORDADO,ACABAMENTO,EMBALAGEM
        }TipoMaquina;


//Máquina
    typedef struct{
        int idMaquina;
        char nomeMaquina[MAXIMO_NOME_MAQUINAS];
        TipoMaquina tipoMaquina;
    }maquina;

   
//Lista Máquinas
    typedef struct{
        int contMaq;
        maquina *listaMaquinas;    
    }MaquinasGeral;



 //Funções de memória dinâmica
    void inicializar_Maquinas(MaquinasGeral *maquinas, int capacidade_inicial);
    void libertar_Memoria_Maquinas(MaquinasGeral *maquina);
    void realocar_Memoria_Maquinas(MaquinasGeral *Maquina);
        
        
//Funções utilizadas em máquina.c
    void imprimir_Maquina(maquina maquina);
    void apagar_Informacao_Maquina(maquina *maquina);
    int procurar_Maquina(MaquinasGeral maquina, int idMaquina); 
    int inserir_Maquina(MaquinasGeral *Maquina);
    void atualizar_Maquina(maquina *maquina);
    
    void adicionar_Maquinana_Lista(MaquinasGeral *maquina);
    void ler_Maquinana_Lista(MaquinasGeral maquina); //Perceber se já existe o id inserido na lista das Máquinas 
    void atualizar_Maquinana_Lista(MaquinasGeral *maquina);
    void remover_Maquinana_Lista(MaquinasGeral *Maquina);
    void listar_Maquinas(MaquinasGeral *maquina);
    
    //Funções referentes aos relatórios. 
    void maquinas_Mais_Utilizadas(MaquinasGeral maquina);
    void tempo_Medio_Producao(MaquinasGeral *maquina, categoria_produtos *categoria);
    void tempo_Maximo_Minimo_Producao(MaquinasGeral *maquina, categoria_produtos *categoria);
    

#ifdef __cplusplus
extern "C" {
#endif




#ifdef __cplusplus
}
#endif

#endif /* MÁQUINA_H */
#endif// MAQUINA_H