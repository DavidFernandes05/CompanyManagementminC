/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cFiles/file.h to edit this template
 */

/* 
 * File:   encomendas.h
 * Author: David Fernandes
 *
 * Created on 26 de novembro de 2024, 14:02
 * Neste ficheiro contem as funçõs para os encomendas.c os prototipos e as estruturas
 */

#ifndef ENCOMENDAS_H
#define ENCOMENDAS_H

#ifdef __cplusplus
extern "C" {
#endif
#include "produto.h" 
#include "input.h"


    
 //Defines para as encomendas
//Define para pedir encomenda  
#define MAX_ENCOMENDAS 100
#define MIN_ENCOMENDAS 1
#define MSG_ID_ENCOMENDA "Qual o id da encomenda?"
//defines para a quantidade de  produtos das encomendas    
#define MIN_ITENS_ENCOMENDA 1
#define MAX_ITENS_ENCOMENDA 50
#define MSG_OBTER_ITNS "Quantos produtos tem a encomenda? [1-50]"
#define MSG_OBTER_QNTD "Qual a quantidade do produto?"
//Define para os produtos das encomendas
#define MIN_ID_PRODUTO 1
#define MAX_ID_PRODUTO 999
#define MSG_ID_PRODUTO "Qual o id do produto que quer adicionar"
//define para a prioridade para as encomendas
#define OBTER_PRIORIDADE_ECONMENDA "Qual a prioridade(1.Baixa 2.Média 3.Alta)?"
#define PRIORIDADE_BAIXA 1
#define PRIORIDADE_MEDIA 2
#define PRIORIDADE_ALTA 3
//defines para o estado da encomenda
#define OBTER_ESTADO_ENCOMENDA "Qual o estado da encomenda(1.Aberta 2.Produção 3.Finalizada)?"
#define ESTADO_ENCOMENDA_ABERTA 1
#define ESTADO_ENCOMENDA_PRODUCAO 2
#define ESTADO_ENCOMENDA_FINALIZADA 3
//defines para taxa de cumprimento 
#define MSG_OBTER_TAXACUMPRIMENTO "Qual a taxa de cumprimento? [0%-100%]"
#define MIN_TAXACUPRIMENTO_ENCOMENDA 0
#define MAX_TAXACUPRIMENTO_ENCOMENDA 100
    
    
    
    
//Estruturas para as encomendas
//estretura para a data de registo de uma encomenda
    typedef struct{
        int ano, mes, dia, horas, minutos, segundos;
    }Data_reg;
    //estretura para os produtos das encomendas
    typedef struct { 
        int id_produto; 
        int quantidade;
    }Produto_encomenda;
    //estretura para as encomendas
    typedef struct{
        int id_encomenda;
        int id_cliente;
        Data_reg data_reg;
        Data_reg data_finalizacao;
        int prioridade_encomenda;
        int estado_da_encomenda;
        float taxa_cumprimento_encomenda;
        int numero_produto; 
        Produto_encomenda *produto;
        int tempo_exe;
    }encomenda;
    //estretura para a lista de encomendas 
    typedef struct {
    int contador;
     int capacidade;
    encomenda *encomendas; 
   }Listaencomendas;
    
    
   
     //Funções para a memoria dinamica
    void inicializar_encomendas(Listaencomendas *encomendas,int capacidadeInicial);
    void liberar_encomendas(Listaencomendas *encomendas);
     
    
   //Funções do crud para as encomendas 
    void criar_Encomendas (Listaencomendas *encomenda);
    void procurar_Encomendas(Listaencomendas encomendas);
    void att_Encomendas(Listaencomendas *encomendas);
    void Rmv_Encomendas(Listaencomendas *encomendas);

   //Funções para os relatorios das encomendas
    void listar_Estado_encomenda(Listaencomendas *encomendas, int estado_encomenda);
    void listar_encomendas_prioridade(Listaencomendas encomendas, int prioridade_encomenda);
    void Ver_Todas_encomendas(Listaencomendas *encomendas);
    void calcularTempoEncomenda(Listaencomendas *enc, categoria_produtos *categorias);

   
    //teste de relatorio de algoritmo
     void Listar_encomendas_auto(Listaencomendas *encomendas);
     //void calcular_Tempo_Producao(Listaencomendas *encomendas);
     //void calcular_tempo_encomenda_fi(Listaencomendas *encomendas,categoria_produtos *produtos);
     //void gerarRelatorioProducao(Listaencomendas *encomendas, int total_encomendas, categoria_produtos *categorias);
  
    
    
    
    
    
    //Se der tempo venho aqui
    /*
    
    void calcular_Tempo_Producao(Listaencomendas *encomendas);
    void calcular_Tempo_Medio_Producao(Listaencomendas *encomendas); 
    */
    //algoritmo de produçao parte "extra" ainda vamos ver se 
       /*
    void calcular_Sequencia_Producao(Listaencomendas *encomendas);
    void simular_Inclusao_Encomenda(Listaencomendas *encomendas);
    */
  
    
    
#ifdef __cplusplus
}
#endif

#endif /* ENCOMENDAS_H */