/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cFiles/file.h to edit this template
 */

/* 
 * File:   produtos.h
 * Author: ricardo
 *
 * Created on 9 de dezembro de 2024, 18:04
 */

#ifndef PRODUTOS_H
#define PRODUTOS_H

#ifdef __cplusplus
extern "C" {
#endif
#define MAXIMO_NOME 50
#define MIN_TEMPO_EXECUCAO 1
#define MAX_TEMPO_EXECUCAO 9999
#define MIN_ID_MAQUINA 1
#define MAX_ID_MAQUINA 9999
#define MIN_ID_PRODUTO 1
#define MAX_ID_PRODUTO_2 9999
#define MIN_CATEGORIA 1
#define MAX_CATEGORIA 6
#define MIN_TAMANHO 1
#define MAX_TAMANHO 6
    
   
    //tipo de calçados
  typedef enum{ TSHIRT, CAMISAS, CAMISOLAS, POLOS, SWEAT, CASACOS} 
    categoria;
    
    
    typedef struct { 
        int id_maquina; 
        int tempo_execucao;
    }Maquina;
    
    
    //produto
  typedef struct{
        int id_produto;
        char nome_produto [MAXIMO_NOME];
        categoria categoria_produto;
        Maquina maquina_tempo_execucao;
        int tamanho_roupa;
    }Produto;
    
    
    //armazenar produtos dinamicos
   typedef struct {
        int contador;
        int capacidade;
        Produto *produtos;   // apontador para o array dinâmico de produtos 
   }categoria_produtos;
   
   
   //CRUD
   // void criar_Produto(categoria_produtos *categoria);   
    void criar_produto(categoria_produtos *categoria, Produto novo_produto);    
    void ler_Produto(categoria_produtos categoria);  
    void atualizar_Produto(categoria_produtos *categoria);  
    void eliminar_Produto(categoria_produtos *categoria);  
    void inserir_Produto(categoria_produtos *categoria);
    
    
    // Lista de produtos
    void lista_Produto(categoria_produtos categoria); 
 void mostrarprodutos(categoria_produtos *produtos);

    // Relatórios
    int TotalProdutos(categoria_produtos categoria);
    void Produtos_Categoria(categoria_produtos categoria,int *categorias, int total_categorias);
    //void relatorio_Produtos_Categoria(categoria_produtos categoria);
    //int relatorio_Maior_Menor_Tamanho(categoria_produtos categoria);
    int Maior_Menor_Tamanho(categoria_produtos categoria, Produto *maior, Produto *menor);


    //funçoes 
    void iniciar_categoria(categoria_produtos *categoria, int capacidade_minima);
    void apagar_categoria(categoria_produtos *categoria);
    int procurar_Produto(categoria_produtos categoria, int id_produto);


    
#ifdef __cplusplus
}
#endif

#endif /* PRODUTOS_H */