/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cFiles/main.c to edit this template
 */

/* 
 * File:   produtos.c
 * Author: ricardo
 *
 * Created on 1 de dezembro de 2024, 18:04
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "input.h"
#include "produto.h"

// Função para criar/adicionar um produto utilizando memória dinâmica
void criar_produto(categoria_produtos *categoria, Produto novo_produto) {
    // Verifica se o tamanho total do arry foi atingido e necessita de aumentar 
    if (categoria->contador >= categoria->capacidade) {
        // Aumenta o tamanho do arry recorrendo a memória dinâmica 
        int nova_capacidade = categoria->capacidade * 2;
        if (nova_capacidade == 0) {
            nova_capacidade = 1; //A capacidade inicial mínima é configurada como 1 para garantir que pelo menos um produto possa ser armazenado, mesmo que a capacidade inicial tenha sido 0.
        }
        Produto *temp = realloc(categoria->produtos, nova_capacidade * sizeof(Produto));
        if (temp == NULL) {
            printf("Erro! Falha ao realocar memória para o novo produto.\n");
            return; // Ocorre uma falhar na alocação de memória dinâmica
        }
        categoria->produtos = temp;
        categoria->capacidade = nova_capacidade;
    }
    // Adiciona o novo produto ao arry 
    categoria->produtos[categoria->contador] = novo_produto;
    categoria->contador++;
    return;
}
    

int novo_Produto(categoria_produtos *categoria) {
    // alocar o array de produtos 
    if (categoria->produtos == NULL) {  // se o ponteiro produtos dentro da categoria for null, significa que nenhum arry foi alocado ainda.
        categoria->produtos = (Produto*)malloc(sizeof(Produto)); //utiliza a função malloc para alocar memória necessaria para um elemento do tipo produtos 
        if (categoria->produtos == NULL) {
            printf("Erro! Falha na alocação de memória.");
            return -1;  // caso malloc return null, a mensagem de erro é apresentada
        }
    } else {
        // usamos realloc para aumentar o tamanho do array
        Produto *temp = (Produto*)realloc(categoria->produtos, (categoria->contador + 1) * sizeof(Produto));  //utilizamos a função malloc para expandir o arry existente. o novo tamanho é calculado pelo que vem a frente.
        if (temp == NULL) { // se o realloc falhar, caso retorne null é escrita a mensagem de erro
            printf("Erro! Falha ao realocar memória para o novo produto.");
            return -1;
        }
        categoria->produtos = temp;  // atualiza o apontador categoria->produtos para o endereço retornado pelo realloc. 
    } 
    // Neste caso, se o realloc falhar, ele retorna null e não modifica o bloco de memória original. ao usar um apontador temporário que evita que o apontador original seja modificado com um  null.
    
    Produto novo_produto;
    novo_produto.id_produto = valorintpequeno(MIN_ID_PRODUTO, MAX_ID_PRODUTO_2, "Insira o ID do produto: "); 
        if (procurar_Produto(*categoria, novo_produto.id_produto) != -1) {   //a função (verfica se um produto com esse ID já existe na lista de produtos da categoria), o if verifica se o retorno de procurar produto é diferente de -1, se for igual a -1 significa que esse número de ID já existe 
        printf("Erro! Já existe um produto com esse ID.");
        return -1; 
        }
   
    lerfrase (novo_produto.nome_produto, MAXIMO_NOME, "Insira o nome do produto: "); 
    novo_produto.categoria_produto = valorintpequeno(MIN_CATEGORIA, MAX_CATEGORIA, "Escolha a categoria do produto\n 1 - T-shirt\n 2 - Camisas\n 3 - Camisolas\n 4 - Polos\n 5 - Sweats\n 6 - Casacos: ");
    novo_produto.maquina_tempo_execucao.id_maquina = valorintpequeno(MIN_ID_MAQUINA, MAX_ID_MAQUINA     , "Insira o ID da máquina: ");
    novo_produto.maquina_tempo_execucao.tempo_execucao = valorintpequeno(MIN_TEMPO_EXECUCAO, MAX_TEMPO_EXECUCAO, "Insira o tempo de execução: ");
    novo_produto.tamanho_roupa = valorintpequeno(MIN_TAMANHO, MAX_TAMANHO, "Insira o tamanho do produto, sendo que (1-XS, 2-S, 3-M, 4-L, 5- XL, 6-XXL): ");

    
    categoria->produtos[categoria->contador] = novo_produto; //categoria->produtos é um apontador que armazena os produtos da categoria, cada posição é ocupada por um elemento do tipo Produto
    categoria->contador++; //Incrementa o a categoria apontada por contador 

    return 0; 
}
 

void iniciar_categoria(categoria_produtos *categoria, int capacidade_minima) {
    if (capacidade_minima <= 0) {  //representa a quantidade inicial de espaço que será guardado no arry diâmico de produtos. Caso este seja inferior ou igual a 0 será considerado inválido.
        printf("Valor da capacidade inicial inválido. O sistema utilizará o padrão de 8 automáticamente \n");
        capacidade_minima = 8;  //define a capacidade inicial como 8, garantido que um valor mínimo seja alocado para vir a evitar erros
    }

    categoria->contador = 0; // mete o contador a 0 para garantir que não haja 'lixo' em memória 
    categoria->capacidade = capacidade_minima; //define a capacidade minima de 8
    categoria->produtos = (Produto *)malloc(capacidade_minima * sizeof(Produto));  //função malloc: aloca memória suficiente para armazenar a capacidade_minima elementos do produto. o apontador produtos da estrutura categoria é configurado para apontar para a memória alocada 
    if (categoria->produtos == NULL) { //se a função malloc não conseguir alocar memória sufiente por exemplo devido a falta de memória, ela returna null
        printf("Erro! Não foi possível alocar memória para os produtos.\n");
        exit(EXIT_FAILURE); //termina o programa porque a inicialização do programa falhou e o sistema não pode continuar
    }
}

//Função para apagar categoria.
void apagar_categoria(categoria_produtos *categoria) {
    if (categoria->produtos != NULL) { //verificação do apontador produtos, não é null, para evitar de problemas de tentar libertar memória que não existe 
        free(categoria->produtos); //liberar a memória anteriormente alocada para o array dinâmico de produtos 
        categoria->produtos = NULL; //depois de libertada a memória, o apontador produtos é redefinifo como null 
    }

    categoria->contador = 0; //igualado a 0, indicando que não há mais produtos armazenados 
    categoria->capacidade = 0; //tambem igualado a 0, indicando que não há mais espaço reservado 
}
    
    
void imprimir_Produto(Produto produto) {
    switch (produto.tamanho_roupa){
        case 1:
            printf("\nID: %d | Nome: %s | Categoria: %d | Máquina: %d | Tempo Execução: %d | Tamanho roupa: XS\n",
            produto.id_produto, produto.nome_produto,produto.categoria_produto, 
            produto.maquina_tempo_execucao.id_maquina, produto.maquina_tempo_execucao.tempo_execucao);
            break ;
        case 2:
            printf("\nID: %d | Nome: %s | Categoria: %d | Máquina: %d | Tempo Execução: %d | Tamanho roupa: S\n",
            produto.id_produto, produto.nome_produto ,produto.categoria_produto, 
            produto.maquina_tempo_execucao.id_maquina, produto.maquina_tempo_execucao.tempo_execucao);
            break ;
        case 3:
            printf("\nID: %d | Nome: %s | Categoria: %d | Máquina: %d | Tempo Execução: %d | Tamanho roupa: M\n",
            produto.id_produto, produto.nome_produto ,produto.categoria_produto, 
            produto.maquina_tempo_execucao.id_maquina, produto.maquina_tempo_execucao.tempo_execucao);
            break ;
        case 4:
            printf("\nID: %d | Nome: %s | Categoria: %d | Máquina: %d | Tempo Execução: %d | Tamanho roupa: L\n",
            produto.id_produto, produto.nome_produto ,produto.categoria_produto, 
            produto.maquina_tempo_execucao.id_maquina, produto.maquina_tempo_execucao.tempo_execucao);
            break ;
        case 5:
            printf("\nID: %d | Nome: %s | Categoria: %d | Máquina: %d | Tempo Execução: %d | Tamanho roupa: XL\n",
            produto.id_produto, produto.nome_produto ,produto.categoria_produto,produto.maquina_tempo_execucao.id_maquina, produto.maquina_tempo_execucao.tempo_execucao);
            break ;
        case 6:
            printf("\nID: %d | Nome: %s | Categoria: %d | Máquina: %d | Tempo Execução: %d | Tamanho roupa: XXL\n",
            produto.id_produto, produto.nome_produto ,produto.categoria_produto,produto.maquina_tempo_execucao.id_maquina, produto.maquina_tempo_execucao.tempo_execucao);
            break ;
    }
}

    
void apagar_Produto(Produto *produto) {
        produto->id_produto = 0;
        strcpy(produto->nome_produto, "");
        produto->categoria_produto = TSHIRT; //<--------- Ver com o professor, se não existe outra forma de colocar a categoria a '0'
        produto->maquina_tempo_execucao.id_maquina= 0;
        produto->maquina_tempo_execucao.tempo_execucao= 0;
        produto->tamanho_roupa = 0;
    
 }
    
int procurar_Produto(categoria_produtos categoria, int id_produto) {
    int i;
    for (i = 0; i < categoria.contador; i++) { //percorre o array de produtos armazenados na categoria 
        if (categoria.produtos[i].id_produto == id_produto) { // para cada produto no arry, o código verifica se o id_produto é igual ao id introduzido
            return i; //return i caso seja encontrado o id
        }
    }
    return -1; //caso não seja encontrado o id
}
  
//CRUD
//Função inserir produto
void inserir_Produto(categoria_produtos *categoria) {
        if (novo_Produto(categoria) == -1) {  //função novo_Produto que tentar inserir um novo produto a categoria 
            printf("Erro: Esse produto já existe ou não foi possível criar.");
    }
}
    
//Ler
void ler_Produto(categoria_produtos categoria) {
    int i;
    for (i = 0; i < categoria.contador; i++) { 
        imprimir_Produto(categoria.produtos[i]);
    }
 }

  
//Atualizar
void atualizar_Produto(categoria_produtos *categoria) {
    int id_produto = valorintpequeno(MIN_ID_PRODUTO, MAX_ID_PRODUTO_2,"Insira o ID do produto que deseja atualizar: ");
    int numero = procurar_Produto(*categoria, id_produto);
       
        if (numero != -1) {
            lerfrase (categoria->produtos[numero].nome_produto, MAXIMO_NOME,"Insira o novo nome do produto: ");
            printf("Escolha a nova categoria do produto que deseja: \n");
            printf("1 - Tshirt\n");
            printf("2 - Camisas\n");
            printf("3 - Camisolas\n");
            printf("4 - Polos\n");
            printf("5 - Sweat\n");
            printf("6 - Casacos\n");
            categoria->produtos[numero].categoria_produto = valorintpequeno(MIN_CATEGORIA, MAX_CATEGORIA,"Insira o número correspondente à categoria desejada: ");
            categoria->produtos[numero].maquina_tempo_execucao.id_maquina = valorintpequeno(MIN_ID_MAQUINA, MAX_ID_MAQUINA,"Insira o novo ID da máquina: ");
            categoria->produtos[numero].maquina_tempo_execucao.tempo_execucao = valorintpequeno(MIN_TEMPO_EXECUCAO, MAX_TEMPO_EXECUCAO,"Insira o novo tempo de execução: ");
            categoria->produtos[numero].tamanho_roupa = valorintpequeno(MIN_TAMANHO, MAX_TAMANHO, "Insira o novo tamanho do produto, sendo que (1-XS, 2-S, 3-M, 4-L, 5- XL, 6-XXL): ");
            printf("O produto foi atualizado.\n");
        } else {
            printf(" ERRO! O produto não foi encontrado.\n");
    }
 }
  
//Função para eliminar produto já criado com memória dinânica
void eliminar_Produto(categoria_produtos *categoria) {
    int i;
    int numero = procurar_Produto(*categoria, valorintpequeno(MIN_ID_PRODUTO, MAX_ID_PRODUTO_2, "Insira o ID do produto que deseja remover: "));
        if (numero != -1) { //se numero != -1, significa que o produto foi encontrado e a sua posição no arry é numero 
            for (i = numero; i < categoria->contador - 1; i++) { //o ciclo começa no indice numero (onde o produto foi encontrado) e vai até ao penultimo produto (categoria->contador - 1)
            categoria->produtos[i] = categoria->produtos[i + 1]; // para cada repetição, o produto na posição i+1, é movido para a posição i deslocando todos os produtos uma posição para a esquerda
        }
        // Apaga o último produto no fim dos deslocamentos 
        apagar_Produto(&categoria->produtos[categoria->contador - 1]);

        // Após a remoção de um produto, o numero total de produtos (contador) é decrementado. Chama-se a função realloc para reduzir o tamanho do arry de produtos
        Produto *temporario = (Produto*) realloc(categoria->produtos, (categoria->contador - 1) * sizeof(Produto));
        if (temporario != NULL || categoria->contador == 1) {// garante que o arry será realocado com sucesso
            categoria->produtos = temporario; //  se a realocação for bem sucessida, o apontador categoria->produtos será atualizado para o novo endereço de memória
        }

        categoria->contador--; //Como é removido um produto o contador e decrementado uma vez 
        printf("Produto removido com sucesso.\n");
         } else {
        printf("Erro: Produto não encontrado.");
    }
}

// mostrar os produtos que estao disponiveis
void mostrarprodutos(categoria_produtos *produtos){
    int i;
    if (produtos->contador == 0){
        printf("Lista de produtos vazia !!!\n");
    }
    printf("------------------------------------\n");
    printf("Produtos no sistema:\n");
    printf("------------------------------------\n");
    for(i=0;i<produtos->contador;i++){
        printf ("Produto %d\n",produtos->produtos[i].id_produto);
        printf ("Nome do produto %s\n",produtos->produtos[i].nome_produto);
        printf("------------------------------------\n");
    }

    
}
 
//lista de produtos
void lista_Produto(categoria_produtos categoria) {
        int i;
        for (i = 0; i < categoria.contador; i++) {  //percorrer todos os produtos da categoria 
            imprimir_Produto(categoria.produtos[i]);  //escrever todos os produtos da categoria 
    }
 }
 
// Função para obter o total de produtos    
int TotalProdutos(categoria_produtos categoria) {
    if (categoria.produtos == NULL || categoria.contador < 0) { //caso seja null e inferior a 0
        return 0; //não existe produtos disponíveis na categoria 
    }
    return categoria.contador; //caso for != null e superior a 0, a função retorna categoria.contador que é o número total de produtos na categoria
}

    // Função para obter a contagem de produtos por categoria
void Produtos_Categoria(categoria_produtos categoria, int *categorias,int total_categorias) {
    int i;
    // Validação dos parâmetros de entrada
    if (categorias == NULL) { // se o apontdor for null retorna erro
            printf("Erro: O array de contagem de categorias é inválido (NULL).\n");
            return;
        }
        if (total_categorias <= 0) { // se o apontador categorias for menor ou igual a 0, retorna erro 
            printf("Erro: Número total de categorias inválido.\n");
            return;
        }
        // Inicializa os contadores
        for (i = 0; i < total_categorias; i++) { // como inicializa categorias a 0, o contador de todas as categorias será 0 
        categorias[i] = 0;
    }
    for (i = 0; i < categoria.contador; i++) { // a função percorre todos os produtos na categoria onde categoria.contador é o número de produtos da categoria 
        int categoriaTotal = categoria.produtos[i].categoria_produto; // para cada produto a função acessa categoria.produto, que indica a que categoria o produto pertence 
        if (categoriaTotal >= 0 && categoriaTotal < total_categorias) { // após receber o valor de categoriaTotal a função verifica se esse indice está dentro dos valores válidos 
            categorias[categoriaTotal]++; //se for válido, o o contador correspondente a categoria e incrementado
        } else {
            printf("Aviso: Produto com categoria inválida encontrado (ID: %d, Categoria: %d).\n",categoria.produtos[i].id_produto, categoria.produtos[i].categoria_produto); // caso seja inválido, a função escreve uma mensagem de aviso.
        }
    }
}

// Função para encontrar o maior e o menor tamanho de calçado
int Maior_Menor_Tamanho(categoria_produtos categoria, Produto *maior, Produto *menor) {
    int i;
    if (categoria.contador == 0 || categoria.produtos == NULL) { //verifica se não há produtos cadastrados na categoria, (contador = 0) e verifica se o apontador produtos do tipo categoria é null
        printf("Erro: Nenhum produto cadastrado ou estrutura inválida.\n"); //se for verdadeiro escreve isto
        return -1; // Erro
    }
    // Inicializa maior e menor com o primeiro produto
    *maior = categoria.produtos[0];
    *menor = categoria.produtos[0];
    for (i = 1; i < categoria.contador; i++) { //percorre todos os produtos da categoria e atualiza as variaveis maior e menor, começando no segundo porque o primeiro já foi defenido como sendo o maior e o menor 
        if (categoria.produtos[i].tamanho_roupa > maior->tamanho_roupa) { // se o tamanho do produto atual for maior do que o tamanho do produto armazenado em *maior então o produto atual torna-se no novo produto maior 
            *maior = categoria.produtos[i];
        }
        if (categoria.produtos[i].tamanho_roupa < menor->tamanho_roupa) {// se o tamanho do produto atual for menor do que o tamanho do produto armazenado em *menor então o produto atual torna-se no novo produto menor 
            *menor = categoria.produtos[i];
        }
    }
    
    return 0; 
}